moddules_info = "[{\"name\": \"login\", 	\"isEffective\": 1 }, { 	\"name\": \"tasks\", 	\"isEffective\": 1 }, { 	\"name\": \"packet\", 	\"isEffective\": 1 }]"
