# -*- coding: utf-8 -*-
redis_host = '47.95.193.202'
redis_port = 6378
redis_pwd = '12345678dx'
