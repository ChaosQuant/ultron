# -*- coding: utf-8 -*-
import datetime
import time
import json
import zlib
import base64
import os
import pdb
from ultron.cluster.work.extern_modules.base_module import BaseModule

class Module(BaseModule):
    def __init__(self, name, wid, token, redis_client):
        super(Module, self).__init__(name, wid, token, redis_client)
        self._func = {'upload_packet':self.upload_packet}
        self._namespace = 'packet'
        
    def process_respone(self, result):
        name = result['name']
        opcode = result['opcode']
        self._func[opcode](result)
    
    def upload_packet(self, result):
        uid = result['uid']
        dir_name = result['dir_name']
        file_info = result['file_info']
        all_dir_name = os.path.join(str(uid), dir_name)
        file_list = []
        if not os.path.exists(all_dir_name):
            os.makedirs(all_dir_name)
        for file in file_info:
            file_name = file['file_name']
            file_content = file['content']
            file_content = zlib.decompress(base64.b64decode(file_content))
            if os.path.exists(os.path.join(all_dir_name, file_name)):
                os.remove(os.path.join(all_dir_name, file_name))
            with open(os.path.join(all_dir_name, file_name), 'wb') as f:
                if f.write(file_content) == len(file_content):
                    file_list.append(str(file_name.split('.')[0]))
                    
        second_time = time.time()
        task_id = int(second_time * 1000000 + datetime.datetime.now().microsecond)
        ## 通知主节点发布成功，进行启动
        packet_info = {'name':'tasks','opcode':'update_task',
                      'dir_name':all_dir_name,'tasks':file_list,'wid':self._wid,
                      'token':self._token}
        self._redis_client.hset('ultron:work:ctask', task_id, json.dumps(packet_info))
        