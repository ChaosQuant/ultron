import os
setting_info='{"queue": {"type": "redis", "host": "127.0.0.1", "port": 1234, "pwd": "123456", "db": 1}}'
file_name = os.path.join(os.getcwd(), __file__)
